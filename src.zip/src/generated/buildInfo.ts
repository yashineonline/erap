// AUTO-GENERATED on build. Do not edit.
export const APP_VERSION = "0.06" as const;
export const BUILD_DATE_ISO = "2026-01-20T10:53:21.909Z" as const;
