declare module "epubjs" {
    const ePub: any;
    export default ePub;
  }
  