<template>
    <div class="h-full">
      <router-view />
    </div>
  </template>
  